import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { breakdowns, mechanics } from "@/db/schema";
import { apiError } from "@/lib/api";
import { getSessionUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return apiError("Please sign in to view your activity.", 401);
  const items = await db.select({
    id: breakdowns.id,
    mechanicId: breakdowns.mechanicId,
    shopName: mechanics.shopName,
    action: breakdowns.action,
    issue: breakdowns.issue,
    createdAt: breakdowns.createdAt,
  }).from(breakdowns).innerJoin(mechanics, eq(breakdowns.mechanicId, mechanics.id))
    .where(eq(breakdowns.userId, user.id)).orderBy(desc(breakdowns.createdAt)).limit(50);
  return Response.json({ breakdowns: items });
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  const mechanicId = typeof body?.mechanicId === "string" ? body.mechanicId : "";
  if (!/^[0-9a-f-]{36}$/i.test(mechanicId)) return apiError("Invalid workshop.");
  const [shop] = await db.select({ id: mechanics.id }).from(mechanics).where(eq(mechanics.id, mechanicId)).limit(1);
  if (!shop) return apiError("Workshop not found.", 404);
  const user = await getSessionUser();
  // Anonymous visitors can call or navigate immediately; only account activity is retained.
  if (!user) return Response.json({ success: true });
  const lat = Number(body.latitude);
  const lng = Number(body.longitude);
  await db.insert(breakdowns).values({
    userId: user.id,
    mechanicId,
    action: body.action === "navigate" ? "navigated" : "called",
    issue: typeof body.issue === "string" ? body.issue.trim().slice(0, 120) || "Roadside assistance" : "Roadside assistance",
    latitude: Number.isFinite(lat) && lat >= -90 && lat <= 90 ? lat : null,
    longitude: Number.isFinite(lng) && lng >= -180 && lng <= 180 ? lng : null,
  });
  return Response.json({ success: true });
}
