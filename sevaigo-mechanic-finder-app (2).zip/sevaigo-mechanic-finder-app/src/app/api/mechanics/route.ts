import { randomBytes } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { mechanics, notifications, users } from "@/db/schema";
import { apiError, cleanText, validImageUrl } from "@/lib/api";
import { getSessionUser } from "@/lib/auth";
import { DEMO_LOCATION, getNearbyMechanics } from "@/lib/mechanics";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const params = new URL(request.url).searchParams;
  const lat = Number(params.get("lat"));
  const lng = Number(params.get("lng"));
  const latitude = Number.isFinite(lat) && lat >= -90 && lat <= 90 && params.has("lat") ? lat : DEMO_LOCATION.latitude;
  const longitude = Number.isFinite(lng) && lng >= -180 && lng <= 180 && params.has("lng") ? lng : DEMO_LOCATION.longitude;
  const shops = await getNearbyMechanics({
    latitude,
    longitude,
    radiusKm: Number(params.get("radius")) || 5,
    vehicleType: params.get("vehicle") || "all",
    search: params.get("search") || "",
    sort: params.get("sort") || "distance",
    openOnly: params.get("open") === "true",
    availableOnly: params.get("available") === "true",
  });
  return Response.json({ shops, latitude, longitude }, { headers: { "Cache-Control": "no-store" } });
}

export async function POST(request: Request) {
  const user = await getSessionUser();
  if (!user) return apiError("Please sign in to register a workshop.", 401);
  const body = await request.json().catch(() => null);
  if (!body || typeof body !== "object") return apiError("Invalid request.");

  const existing = await db.select({ id: mechanics.id }).from(mechanics).where(eq(mechanics.ownerUserId, user.id)).limit(1);
  if (existing.length) return apiError("You already have a workshop registered.", 409);

  const shopName = cleanText(body.shopName, 100);
  const ownerName = cleanText(body.ownerName, 80);
  const phone = cleanText(body.phone, 20);
  const address = cleanText(body.address, 250);
  const latitude = Number(body.latitude);
  const longitude = Number(body.longitude);
  const openTime = cleanText(body.openTime, 5) || "08:00";
  const closeTime = cleanText(body.closeTime, 5) || "21:00";
  const validTypes = ["2w", "4w", "truck", "bus"];
  const vehicleTypes: string[] = Array.isArray(body.vehicleTypes) ? body.vehicleTypes.filter((item: unknown): item is string => typeof item === "string" && validTypes.includes(item)) : [];
  const specializations: string[] = Array.isArray(body.specializations) ? body.specializations.filter((item: unknown): item is string => typeof item === "string" && item.length > 0).slice(0, 8) : [];
  const photos: string[] = Array.isArray(body.photos) ? body.photos.map(validImageUrl).filter((item: string | null): item is string => Boolean(item)).slice(0, 4) : [];
  const priceMin = Math.round(Number(body.priceMin));
  const priceMax = Math.round(Number(body.priceMax));
  const yearsExperience = Math.round(Number(body.yearsExperience));

  if (shopName.length < 3 || ownerName.length < 2 || address.length < 8) return apiError("Please complete the shop name, owner name and address.");
  if (phone.replace(/\D/g, "").length < 10) return apiError("Enter a valid contact number.");
  if (!Number.isFinite(latitude) || latitude < -90 || latitude > 90 || !Number.isFinite(longitude) || longitude < -180 || longitude > 180) return apiError("Enter valid map coordinates.");
  if (!vehicleTypes.length || !specializations.length) return apiError("Choose at least one vehicle type and specialization.");
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(openTime) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(closeTime)) return apiError("Enter valid working hours.");
  if (!Number.isFinite(priceMin) || !Number.isFinite(priceMax) || priceMin < 0 || priceMax < priceMin || priceMax > 1000000) return apiError("Enter a valid price range.");

  const slug = `${shopName.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "")}-${randomBytes(3).toString("hex")}`;
  const [shop] = await db.insert(mechanics).values({
    slug,
    ownerUserId: user.id,
    shopName,
    ownerName,
    phone,
    address,
    latitude,
    longitude,
    vehicleTypes,
    specializations,
    openTime,
    closeTime,
    photos: photos.length ? photos : ["/images/workshop-1.jpg"],
    ownerPhoto: validImageUrl(body.ownerPhoto) || "/images/owner-1.jpg",
    priceMin,
    priceMax,
    yearsExperience: Number.isFinite(yearsExperience) ? Math.max(0, Math.min(yearsExperience, 70)) : 1,
  }).returning();
  if (user.role === "user") await db.update(users).set({ role: "owner" }).where(eq(users.id, user.id));
  await db.insert(notifications).values({
    userId: user.id,
    title: "Application received",
    message: `${shopName} is submitted for review. We'll notify you once it is approved.`,
  });
  return Response.json({ shop: { id: shop.id, shopName: shop.shopName, approvalStatus: shop.approvalStatus } }, { status: 201 });
}
