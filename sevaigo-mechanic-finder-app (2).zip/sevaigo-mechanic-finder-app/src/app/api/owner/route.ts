import { eq } from "drizzle-orm";
import { db } from "@/db";
import { mechanics } from "@/db/schema";
import { apiError, cleanText } from "@/lib/api";
import { getSessionUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return apiError("Please sign in.", 401);
  const [shop] = await db.select().from(mechanics).where(eq(mechanics.ownerUserId, user.id)).limit(1);
  return Response.json({ shop: shop || null });
}

export async function PATCH(request: Request) {
  const user = await getSessionUser();
  if (!user) return apiError("Please sign in.", 401);
  const [shop] = await db.select().from(mechanics).where(eq(mechanics.ownerUserId, user.id)).limit(1);
  if (!shop) return apiError("Workshop not found.", 404);
  const body = await request.json().catch(() => null);
  if (!body) return apiError("Invalid request.");
  const availabilityStatus = cleanText(body.availabilityStatus, 10);
  const openTime = cleanText(body.openTime, 5);
  const closeTime = cleanText(body.closeTime, 5);
  const priceMin = Math.round(Number(body.priceMin));
  const priceMax = Math.round(Number(body.priceMax));
  if (!["free", "busy"].includes(availabilityStatus)) return apiError("Choose Free or Busy.");
  if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(openTime) || !/^([01]\d|2[0-3]):[0-5]\d$/.test(closeTime)) return apiError("Enter valid working hours.");
  if (!Number.isFinite(priceMin) || !Number.isFinite(priceMax) || priceMin < 0 || priceMax < priceMin || priceMax > 1000000) return apiError("Enter a valid price range.");
  const [updated] = await db.update(mechanics).set({ availabilityStatus, openTime, closeTime, priceMin, priceMax })
    .where(eq(mechanics.id, shop.id)).returning();
  return Response.json({ shop: updated });
}
