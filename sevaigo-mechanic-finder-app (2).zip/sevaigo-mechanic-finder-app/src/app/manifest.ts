import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "SevaiGo — Roadside Help",
    short_name: "SevaiGo",
    description: "Find trusted mechanics nearby when your vehicle needs help.",
    start_url: "/",
    display: "standalone",
    background_color: "#f7f8fa",
    theme_color: "#e3514b",
    icons: [{ src: "/icon.svg", sizes: "any", type: "image/svg+xml", purpose: "maskable" }],
  };
}
