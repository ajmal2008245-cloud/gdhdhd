"use client";

import { useEffect, useRef, useState } from "react";
import type * as Leaflet from "leaflet";
import type { MechanicView } from "@/lib/mechanic-shared";

export type MapLocation = { latitude: number; longitude: number; label: string; source: "demo" | "gps" };

type Props = {
  shops: MechanicView[];
  location: MapLocation;
  selectedId: string | null;
  onSelect: (id: string) => void;
};

const wrenchSvg = '<svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a4 4 0 0 0-5.4 5.4l-5.6 5.6a2 2 0 0 0 2.8 2.8l5.6-5.6a4 4 0 0 0 5.4-5.4l-2.6 2.6-2.8-2.8 2.6-2.6Z"/></svg>';

export default function MechanicMap({ shops, location, selectedId, onSelect }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<Leaflet.Map | null>(null);
  const leafletRef = useRef<typeof import("leaflet") | null>(null);
  const markersRef = useRef<Leaflet.LayerGroup | null>(null);
  const circleRef = useRef<Leaflet.Circle | null>(null);
  const onSelectRef = useRef(onSelect);
  const [ready, setReady] = useState(false);

  useEffect(() => { onSelectRef.current = onSelect; }, [onSelect]);

  useEffect(() => {
    let disposed = false;
    let observer: ResizeObserver | null = null;
    async function setup() {
      const L = await import("leaflet");
      if (disposed || !containerRef.current || mapRef.current) return;
      const map = L.map(containerRef.current, { zoomControl: false, scrollWheelZoom: false })
        .setView([location.latitude, location.longitude], 14);
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank">OpenStreetMap</a> contributors',
      }).addTo(map);
      L.control.zoom({ position: "bottomright" }).addTo(map);
      leafletRef.current = L;
      mapRef.current = map;
      markersRef.current = L.layerGroup().addTo(map);
      circleRef.current = L.circle([location.latitude, location.longitude], {
        radius: 5000,
        color: "#456cae",
        weight: 1,
        dashArray: "5 6",
        opacity: 0.5,
        fillColor: "#5488da",
        fillOpacity: 0.035,
        interactive: false,
      }).addTo(map);
      if (containerRef.current && typeof ResizeObserver !== "undefined") {
        observer = new ResizeObserver(() => map.invalidateSize({ pan: false }));
        observer.observe(containerRef.current);
      }
      setTimeout(() => { if (!disposed) map.invalidateSize({ pan: false }); }, 200);
      setReady(true);
    }
    setup();
    return () => {
      disposed = true;
      observer?.disconnect();
      mapRef.current?.remove();
      mapRef.current = null;
      leafletRef.current = null;
      markersRef.current = null;
      circleRef.current = null;
      setReady(false);
    };
    // The map is initialized once; later location changes are handled below.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const L = leafletRef.current;
    const map = mapRef.current;
    const group = markersRef.current;
    if (!ready || !L || !map || !group) return;
    group.clearLayers();
    const userIcon = L.divIcon({
      className: "map-icon-reset",
      html: '<div class="map-user-pulse"><span class="map-user-dot"></span></div>',
      iconSize: [40, 40], iconAnchor: [20, 20],
    });
    L.marker([location.latitude, location.longitude], { icon: userIcon, zIndexOffset: 500 }).addTo(group);
    shops.forEach((shop) => {
      const active = selectedId === shop.id;
      const icon = L.divIcon({
        className: "map-icon-reset",
        html: `<div class="map-shop-pin ${active ? "active" : ""} ${!shop.isOpen ? "closed" : ""}"><span>${wrenchSvg}</span></div>`,
        iconSize: active ? [50, 56] : [44, 50],
        iconAnchor: active ? [25, 51] : [22, 45],
      });
      L.marker([shop.latitude, shop.longitude], { icon, zIndexOffset: active ? 400 : 100 })
        .on("click", () => onSelectRef.current(shop.id)).addTo(group);
    });
    circleRef.current?.setLatLng([location.latitude, location.longitude]);
  }, [shops, location, selectedId, ready]);

  useEffect(() => {
    if (ready) mapRef.current?.flyTo([location.latitude, location.longitude], 14, { duration: 0.75 });
  }, [location.latitude, location.longitude, ready]);

  useEffect(() => {
    if (!ready || !selectedId) return;
    const shop = shops.find((item) => item.id === selectedId);
    if (shop) mapRef.current?.panTo([shop.latitude, shop.longitude], { animate: true, duration: 0.5 });
  }, [selectedId, ready, shops]);

  return <div ref={containerRef} className="mechanic-map" role="application" aria-label="Map of nearby mechanics" />;
}
