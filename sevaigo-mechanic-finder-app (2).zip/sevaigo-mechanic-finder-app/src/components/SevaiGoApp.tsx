"use client";

import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import {
  ArrowRight, ArrowUpRight, Bell, Bike, CarFront, Check, CheckCircle2, ChevronDown,
  ChevronRight, Clock3, Compass, Heart, LifeBuoy, LocateFixed, LogOut, MapPin,
  Menu, Moon, Navigation, Phone, Plus, Search, Settings2, ShieldCheck, SlidersHorizontal,
  Sparkles, Star, Store, Sun, Trash2, Truck, UserRound, Wrench, X, Zap,
} from "lucide-react";
import MechanicMap, { type MapLocation } from "@/components/MechanicMap";
import ShopCard from "@/components/ShopCard";
import ShopDetail, { type ShopReview } from "@/components/ShopDetail";
import type { PublicUser } from "@/lib/auth";
import { t, type Language } from "@/lib/copy";
import { DEMO_LOCATION, type MechanicView } from "@/lib/mechanic-shared";

type View = "explore" | "saved" | "vehicles" | "activity" | "partner" | "owner" | "admin";
type VehicleItem = { id: string; make: string; model: string; year: number; type: string; registration: string | null; createdAt: string };
type BreakdownItem = { id: string; mechanicId: string; shopName: string; action: string; issue: string; createdAt: string };
type NoticeItem = { id: string; title: string; message: string; isRead: boolean; createdAt: string };
type OwnerShop = { id: string; shopName: string; ownerName: string; address: string; phone: string; photos: string[]; approvalStatus: string; availabilityStatus: string; priceMin: number; priceMax: number; openTime: string; closeTime: string; isVerified: boolean };
type PendingShop = { id: string; shopName: string; ownerName: string; address: string; phone: string; vehicleTypes: string[]; specializations: string[]; photos: string[]; createdAt: string };
type PartnerForm = { shopName: string; ownerName: string; phone: string; address: string; latitude: string; longitude: string; vehicleTypes: string[]; specializations: string[]; openTime: string; closeTime: string; priceMin: string; priceMax: string; yearsExperience: string; ownerPhoto: string; photo: string };

const vehicleChoices = [
  { value: "all", key: "allVehicles" as const, Icon: Compass },
  { value: "2w", key: "twoWheeler" as const, Icon: Bike },
  { value: "4w", key: "fourWheeler" as const, Icon: CarFront },
  { value: "truck", key: "truck" as const, Icon: Truck },
  { value: "bus", key: "bus" as const, Icon: CarFront },
];
const specialtyChoices = ["Engine repair", "Electrical", "Tyre & puncture", "Body work", "AC repair", "Battery", "General service"];

async function apiRequest<T>(url: string, init?: RequestInit): Promise<T> {
  const response = await fetch(url, init);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "Something went wrong. Please try again.");
  return data as T;
}
function jsonOptions(body: unknown, method = "POST"): RequestInit {
  return { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) };
}
function dateLabel(date: string, language: Language) {
  return new Date(date).toLocaleDateString(language === "ta" ? "ta-IN" : "en-IN", { day: "numeric", month: "short", year: "numeric" });
}

export default function SevaiGoApp({ initialShops, initialUser }: { initialShops: MechanicView[]; initialUser: PublicUser | null }) {
  const [view, setView] = useState<View>("explore");
  const [user, setUser] = useState<PublicUser | null>(initialUser);
  const [shops, setShops] = useState<MechanicView[]>(initialShops);
  const [location, setLocation] = useState<MapLocation>({ ...DEMO_LOCATION, source: "demo" });
  const [language, setLanguage] = useState<Language>("en");
  const [theme, setTheme] = useState<"light" | "dark">("light");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notificationOpen, setNotificationOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [vehicleFilter, setVehicleFilter] = useState("all");
  const [sort, setSort] = useState("distance");
  const [openOnly, setOpenOnly] = useState(false);
  const [availableOnly, setAvailableOnly] = useState(false);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [geoLoading, setGeoLoading] = useState(false);
  const [loadingShops, setLoadingShops] = useState(false);
  const [offline, setOffline] = useState(false);
  const [emergencyMode, setEmergencyMode] = useState(false);
  const [toast, setToast] = useState("");
  const [favoriteIds, setFavoriteIds] = useState<string[]>([]);
  const [favoriteShops, setFavoriteShops] = useState<MechanicView[]>([]);
  const [vehicles, setVehicles] = useState<VehicleItem[]>([]);
  const [breakdowns, setBreakdowns] = useState<BreakdownItem[]>([]);
  const [notices, setNotices] = useState<NoticeItem[]>([]);
  const [ownerShop, setOwnerShop] = useState<OwnerShop | null>(null);
  const [pendingShops, setPendingShops] = useState<PendingShop[]>([]);
  const [reviews, setReviews] = useState<ShopReview[]>([]);
  const [reviewSubmitting, setReviewSubmitting] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<"login" | "register">("login");
  const [authName, setAuthName] = useState("");
  const [authEmail, setAuthEmail] = useState("");
  const [authPassword, setAuthPassword] = useState("");
  const [authPhone, setAuthPhone] = useState("");
  const [authError, setAuthError] = useState("");
  const [authSubmitting, setAuthSubmitting] = useState(false);
  const [vehicleForm, setVehicleForm] = useState({ make: "", model: "", year: String(new Date().getFullYear()), type: "4w", registration: "" });
  const [vehicleSubmitting, setVehicleSubmitting] = useState(false);
  const [partnerForm, setPartnerForm] = useState<PartnerForm>({
    shopName: "", ownerName: initialUser?.name || "", phone: initialUser?.phone || "", address: "",
    latitude: String(DEMO_LOCATION.latitude), longitude: String(DEMO_LOCATION.longitude),
    vehicleTypes: ["4w"], specializations: ["Engine repair"], openTime: "08:00", closeTime: "21:00",
    priceMin: "300", priceMax: "2500", yearsExperience: "5", ownerPhoto: "", photo: "",
  });
  const [partnerSubmitting, setPartnerSubmitting] = useState(false);
  const [ownerDraft, setOwnerDraft] = useState({ availabilityStatus: "free", openTime: "08:00", closeTime: "21:00", priceMin: "300", priceMax: "2500" });
  const [ownerSaving, setOwnerSaving] = useState(false);
  const firstLocationRender = useRef(true);

  const say = useCallback((message: string) => setToast(message), []);
  useEffect(() => { if (!toast) return; const timeout = setTimeout(() => setToast(""), 3800); return () => clearTimeout(timeout); }, [toast]);
  useEffect(() => {
    const savedTheme = localStorage.getItem("sevaigo-theme");
    const savedLanguage = localStorage.getItem("sevaigo-language");
    if (savedTheme === "dark") setTheme("dark");
    if (savedLanguage === "ta") setLanguage("ta");
  }, []);
  useEffect(() => { document.documentElement.dataset.theme = theme; localStorage.setItem("sevaigo-theme", theme); }, [theme]);
  useEffect(() => { localStorage.setItem("sevaigo-language", language); document.documentElement.lang = language; }, [language]);

  const refreshShops = useCallback(async (position: MapLocation) => {
    setLoadingShops(true);
    try {
      const data = await apiRequest<{ shops: MechanicView[] }>(`/api/mechanics?lat=${position.latitude}&lng=${position.longitude}&radius=5`);
      setShops(data.shops);
      localStorage.setItem("sevaigo-last-shops", JSON.stringify(data.shops));
      setOffline(false);
    } catch {
      const cached = localStorage.getItem("sevaigo-last-shops");
      if (cached) {
        try { setShops(JSON.parse(cached)); setOffline(true); say("You're offline. Showing your last saved mechanics."); }
        catch { say("Couldn't load nearby mechanics. Please try again."); }
      } else say("Couldn't load nearby mechanics. Please try again.");
    } finally { setLoadingShops(false); }
  }, [say]);

  useEffect(() => {
    if (firstLocationRender.current) {
      firstLocationRender.current = false;
      if (initialShops.length) localStorage.setItem("sevaigo-last-shops", JSON.stringify(initialShops));
      return;
    }
    void refreshShops(location);
  }, [location, refreshShops, initialShops]);

  useEffect(() => {
    if (view !== "explore") return;
    const interval = window.setInterval(() => {
      if (document.visibilityState === "visible") void refreshShops(location);
    }, 45000);
    return () => window.clearInterval(interval);
  }, [view, location, refreshShops]);

  useEffect(() => {
    if (!emergencyMode || location.source !== "gps" || !navigator.geolocation) return;
    const watchId = navigator.geolocation.watchPosition((position) => {
      const latitude = position.coords.latitude;
      const longitude = position.coords.longitude;
      setLocation((previous) => Math.abs(previous.latitude - latitude) + Math.abs(previous.longitude - longitude) > 0.00035
        ? { latitude, longitude, label: "Your current location", source: "gps" }
        : previous);
    }, () => {}, { enableHighAccuracy: true, maximumAge: 15000, timeout: 12000 });
    return () => navigator.geolocation.clearWatch(watchId);
  }, [emergencyMode, location.source]);

  useEffect(() => {
    if (!user) { setFavoriteIds([]); setFavoriteShops([]); setVehicles([]); setBreakdowns([]); setNotices([]); setOwnerShop(null); setPendingShops([]); return; }
    void apiRequest<{ vehicles: VehicleItem[] }>("/api/vehicles").then((data) => setVehicles(data.vehicles)).catch(() => {});
    void apiRequest<{ breakdowns: BreakdownItem[] }>("/api/breakdowns").then((data) => setBreakdowns(data.breakdowns)).catch(() => {});
    void apiRequest<{ notifications: NoticeItem[] }>("/api/notifications").then((data) => setNotices(data.notifications)).catch(() => {});
    void apiRequest<{ shop: OwnerShop | null }>("/api/owner").then((data) => {
      setOwnerShop(data.shop);
      if (data.shop) setOwnerDraft({ availabilityStatus: data.shop.availabilityStatus, openTime: data.shop.openTime, closeTime: data.shop.closeTime, priceMin: String(data.shop.priceMin), priceMax: String(data.shop.priceMax) });
    }).catch(() => {});
    if (user.role === "admin") void apiRequest<{ shops: PendingShop[] }>("/api/admin").then((data) => setPendingShops(data.shops)).catch(() => {});
  }, [user]);

  useEffect(() => {
    if (!user) return;
    void apiRequest<{ ids: string[]; shops: MechanicView[] }>(`/api/favorites?lat=${location.latitude}&lng=${location.longitude}`)
      .then((data) => { setFavoriteIds(data.ids); setFavoriteShops(data.shops); }).catch(() => {});
  }, [user, location.latitude, location.longitude]);

  useEffect(() => {
    if (!selectedId) { setReviews([]); return; }
    let active = true;
    void apiRequest<{ reviews: ShopReview[] }>(`/api/mechanics/${selectedId}/reviews`)
      .then((data) => { if (active) setReviews(data.reviews); }).catch(() => {});
    return () => { active = false; };
  }, [selectedId]);

  const filteredShops = useMemo(() => {
    const term = search.trim().toLowerCase();
    return shops.filter((shop) => vehicleFilter === "all" || shop.vehicleTypes.includes(vehicleFilter))
      .filter((shop) => !term || `${shop.shopName} ${shop.ownerName} ${shop.address} ${shop.specializations.join(" ")}`.toLowerCase().includes(term))
      .filter((shop) => !openOnly || shop.isOpen)
      .filter((shop) => !availableOnly || (shop.isOpen && shop.availabilityStatus === "free"))
      .sort((a, b) => {
        if (sort === "rating") return b.rating - a.rating || a.distanceKm - b.distanceKm;
        if (sort === "open") return Number(b.isOpen) - Number(a.isOpen) || a.distanceKm - b.distanceKm;
        if (sort === "availability") return Number(b.isOpen && b.availabilityStatus === "free") - Number(a.isOpen && a.availabilityStatus === "free") || a.distanceKm - b.distanceKm;
        return a.distanceKm - b.distanceKm;
      });
  }, [shops, vehicleFilter, search, openOnly, availableOnly, sort]);
  const selectedShop = shops.find((shop) => shop.id === selectedId) || favoriteShops.find((shop) => shop.id === selectedId) || null;
  const savedShops = favoriteIds.map((id) => shops.find((shop) => shop.id === id) || favoriteShops.find((shop) => shop.id === id)).filter((shop): shop is MechanicView => Boolean(shop));
  const readyCount = shops.filter((shop) => shop.isOpen && shop.availabilityStatus === "free").length;
  const unreadCount = notices.filter((notice) => !notice.isRead).length;

  function goTo(next: View) {
    setView(next);
    setMobileMenuOpen(false);
    setNotificationOpen(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }
  function clearFilters() { setSearch(""); setVehicleFilter("all"); setOpenOnly(false); setAvailableOnly(false); setSort("distance"); }
  function detectLocation(isEmergency = false) {
    if (isEmergency) { setEmergencyMode(true); goTo("explore"); setTimeout(() => document.getElementById("results")?.scrollIntoView({ behavior: "smooth", block: "start" }), 100); }
    if (!navigator.geolocation) { say("Location is not supported in this browser. Showing the Chennai demo area."); return; }
    setGeoLoading(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLocation({ latitude: position.coords.latitude, longitude: position.coords.longitude, label: "Your current location", source: "gps" });
        setGeoLoading(false);
        say("Location found. Showing mechanics within 5 km.");
      },
      () => { setGeoLoading(false); say("Location access unavailable. Showing the Chennai demo area instead."); },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 30000 },
    );
  }
  function openShop(shop: MechanicView) { setSelectedId(shop.id); }
  function recordAction(shop: MechanicView, action: "call" | "navigate") {
    void apiRequest("/api/breakdowns", jsonOptions({ mechanicId: shop.id, action, latitude: location.latitude, longitude: location.longitude })).catch(() => {});
    if (user) {
      setBreakdowns((previous) => [{ id: `local-${Date.now()}`, mechanicId: shop.id, shopName: shop.shopName, action: action === "call" ? "called" : "navigated", issue: "Roadside assistance", createdAt: new Date().toISOString() }, ...previous]);
    }
  }
  async function toggleFavorite(shop: MechanicView) {
    if (!user) { setAuthOpen(true); say("Sign in to save your favorite workshops."); return; }
    const favorite = !favoriteIds.includes(shop.id);
    setFavoriteIds((previous) => favorite ? [...previous, shop.id] : previous.filter((id) => id !== shop.id));
    try { await apiRequest("/api/favorites", jsonOptions({ mechanicId: shop.id, favorite })); say(favorite ? "Workshop saved to your favorites." : "Workshop removed from favorites."); }
    catch (error) { setFavoriteIds((previous) => favorite ? previous.filter((id) => id !== shop.id) : [...previous, shop.id]); say((error as Error).message); }
  }
  async function shareShop(shop: MechanicView) {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${shop.latitude},${shop.longitude}`;
    const text = `${shop.shopName} · ${shop.address} · ${shop.phone} · ${url}`;
    if (navigator.share) { try { await navigator.share({ title: shop.shopName, text }); return; } catch { /* User dismissed the share sheet. */ } }
    try { await navigator.clipboard.writeText(text); say(t(language, "shareCopied")); } catch { say("Use the WhatsApp or SMS buttons to share this shop."); }
  }
  async function submitReview(rating: number, comment: string) {
    if (!selectedShop) return false;
    setReviewSubmitting(true);
    try {
      const result = await apiRequest<{ rating: number; reviewCount: number }>(`/api/mechanics/${selectedShop.id}/reviews`, jsonOptions({ rating, comment }));
      setShops((previous) => previous.map((shop) => shop.id === selectedShop.id ? { ...shop, rating: result.rating, reviewCount: result.reviewCount } : shop));
      const data = await apiRequest<{ reviews: ShopReview[] }>(`/api/mechanics/${selectedShop.id}/reviews`);
      setReviews(data.reviews);
      say("Thanks for sharing your experience!");
      return true;
    } catch (error) { say((error as Error).message); return false; }
    finally { setReviewSubmitting(false); }
  }
  async function submitAuth(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setAuthError(""); setAuthSubmitting(true);
    try {
      const data = await apiRequest<{ user: PublicUser }>("/api/auth", jsonOptions({ action: authMode, name: authName, email: authEmail, password: authPassword, phone: authPhone }));
      setUser(data.user); setAuthOpen(false); setAuthPassword(""); say(authMode === "register" ? "Welcome to SevaiGo! Your account is ready." : "Welcome back!");
    } catch (error) { setAuthError((error as Error).message); }
    finally { setAuthSubmitting(false); }
  }
  async function signOut() {
    try { await apiRequest("/api/auth", jsonOptions({ action: "logout" })); setUser(null); goTo("explore"); say("You have signed out."); }
    catch (error) { say((error as Error).message); }
  }
  async function submitVehicle(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setVehicleSubmitting(true);
    try {
      const data = await apiRequest<{ vehicle: VehicleItem }>("/api/vehicles", jsonOptions(vehicleForm));
      setVehicles((previous) => [data.vehicle, ...previous]);
      setVehicleForm({ make: "", model: "", year: String(new Date().getFullYear()), type: "4w", registration: "" });
      say("Vehicle added to your garage.");
    } catch (error) { say((error as Error).message); }
    finally { setVehicleSubmitting(false); }
  }
  async function removeVehicle(id: string) {
    try { await apiRequest(`/api/vehicles?id=${id}`, { method: "DELETE" }); setVehicles((previous) => previous.filter((vehicle) => vehicle.id !== id)); say("Vehicle removed."); }
    catch (error) { say((error as Error).message); }
  }
  function togglePartnerArray(key: "vehicleTypes" | "specializations", value: string) {
    setPartnerForm((previous) => ({ ...previous, [key]: previous[key].includes(value) ? previous[key].filter((item) => item !== value) : [...previous[key], value] }));
  }
  async function submitPartner(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setPartnerSubmitting(true);
    try {
      await apiRequest("/api/mechanics", jsonOptions({ ...partnerForm, photos: partnerForm.photo ? [partnerForm.photo] : [] }));
      const data = await apiRequest<{ shop: OwnerShop }>("/api/owner");
      setOwnerShop(data.shop);
      setOwnerDraft({ availabilityStatus: data.shop.availabilityStatus, openTime: data.shop.openTime, closeTime: data.shop.closeTime, priceMin: String(data.shop.priceMin), priceMax: String(data.shop.priceMax) });
      setUser((previous) => previous ? { ...previous, role: previous.role === "admin" ? "admin" : "owner" } : previous);
      goTo("owner"); say("Your workshop was submitted for approval!");
    } catch (error) { say((error as Error).message); }
    finally { setPartnerSubmitting(false); }
  }
  async function saveOwner(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setOwnerSaving(true);
    try {
      const data = await apiRequest<{ shop: OwnerShop }>("/api/owner", jsonOptions(ownerDraft, "PATCH"));
      setOwnerShop(data.shop); await refreshShops(location); say("Workshop details updated.");
    } catch (error) { say((error as Error).message); }
    finally { setOwnerSaving(false); }
  }
  async function handleApproval(id: string, status: "approved" | "rejected") {
    try {
      await apiRequest("/api/admin", jsonOptions({ id, status }, "PATCH"));
      setPendingShops((previous) => previous.filter((shop) => shop.id !== id));
      if (status === "approved") await refreshShops(location);
      say(status === "approved" ? "Workshop approved and published." : "Application declined.");
    } catch (error) { say((error as Error).message); }
  }
  async function openNotifications() {
    if (!user) { setAuthOpen(true); return; }
    setNotificationOpen((previous) => !previous);
    if (unreadCount) {
      setNotices((previous) => previous.map((notice) => ({ ...notice, isRead: true })));
      void apiRequest("/api/notifications", jsonOptions({}, "PATCH")).catch(() => {});
    }
  }

  function gate() {
    return <div className="gate-card"><div className="gate-icon"><ShieldCheck size={29} /></div><h2>{t(language, "signInRequired")}</h2><p>{t(language, "signInDesc")}</p><button className="primary-button" onClick={() => setAuthOpen(true)}>{t(language, "loginContinue")} <ArrowRight size={17} /></button></div>;
  }

  const primaryNav: { view: View; label: string; Icon: typeof Compass }[] = [
    { view: "explore", label: t(language, "navExplore"), Icon: Compass },
    { view: "saved", label: t(language, "navSaved"), Icon: Heart },
    { view: "vehicles", label: t(language, "navVehicles"), Icon: CarFront },
    { view: "activity", label: t(language, "navActivity"), Icon: Clock3 },
  ];
  const partnerNav: { view: View; label: string; Icon: typeof Compass }[] = [
    { view: ownerShop || user?.role === "owner" ? "owner" : "partner", label: t(language, ownerShop || user?.role === "owner" ? "navOwner" : "navPartner"), Icon: Store },
    ...(user?.role === "admin" ? [{ view: "admin" as View, label: t(language, "navAdmin"), Icon: ShieldCheck }] : []),
  ];

  return (
    <div className="app-shell">
      {mobileMenuOpen && <div className="sidebar-mobile-scrim" onClick={() => setMobileMenuOpen(false)} />}
      <aside className={`sidebar ${mobileMenuOpen ? "sidebar-open" : ""}`}>
        <div className="sidebar-top">
          <button className="brand" onClick={() => goTo("explore")} aria-label="SevaiGo home"><span className="brand-mark"><Wrench size={23} strokeWidth={2.6} /></span><span className="brand-wordmark">Sevai<span>Go</span><small>ROADSIDE COMPANION</small></span></button>
          <button className="sidebar-close" onClick={() => setMobileMenuOpen(false)} aria-label="Close menu"><X size={20} /></button>
        </div>
        <div className="sidebar-section-label">{t(language, "menu")}</div>
        <nav className="sidebar-nav" aria-label="Main navigation">
          {primaryNav.map(({ view: itemView, label, Icon }) => <button key={itemView} className={`sidebar-link ${view === itemView ? "active" : ""}`} onClick={() => goTo(itemView)}><Icon size={19} strokeWidth={view === itemView ? 2.35 : 1.9} /><span>{label}</span>{itemView === "saved" && favoriteIds.length > 0 && <span className="nav-count">{favoriteIds.length}</span>}</button>)}
        </nav>
        <div className="sidebar-separator" />
        <div className="sidebar-section-label">{t(language, "forPartners")}</div>
        <nav className="sidebar-nav" aria-label="Partner navigation">{partnerNav.map(({ view: itemView, label, Icon }) => <button key={itemView} className={`sidebar-link ${view === itemView ? "active" : ""}`} onClick={() => goTo(itemView)}><Icon size={19} strokeWidth={1.9} /><span>{label}</span>{itemView === "admin" && pendingShops.length > 0 && <span className="nav-count">{pendingShops.length}</span>}</button>)}</nav>
        <div className="sidebar-spacer" />
        <div className="sidebar-help-card"><span className="sidebar-help-icon"><LifeBuoy size={19} /></span><strong>{t(language, "supportTitle")}</strong><p>{t(language, "supportText")}</p><button onClick={() => detectLocation(true)}>{t(language, "heroButton")} <ArrowUpRight size={15} /></button></div>
        <div className="sidebar-preferences"><div className="language-switch" aria-label="Language"><button className={language === "en" ? "chosen" : ""} onClick={() => setLanguage("en")}>EN</button><button className={language === "ta" ? "chosen" : ""} onClick={() => setLanguage("ta")}>தமிழ்</button></div><button className="theme-button" onClick={() => setTheme((previous) => previous === "light" ? "dark" : "light")} aria-label="Toggle dark mode" title="Toggle dark mode">{theme === "light" ? <Moon size={18} /> : <Sun size={18} />}</button></div>
        <div className="sidebar-account">{user ? <><span className="account-avatar">{user.name.slice(0, 1).toUpperCase()}</span><span className="account-text"><strong>{user.name}</strong><small>{user.email}</small></span><button onClick={signOut} className="account-action" title={t(language, "signOut")} aria-label={t(language, "signOut")}><LogOut size={17} /></button></> : <button className="sidebar-login" onClick={() => { setAuthMode("login"); setAuthOpen(true); }}>{t(language, "signIn")} <ArrowRight size={16} /></button>}</div>
      </aside>

      <div className="workspace">
        <header className="topbar">
          <button className="mobile-menu-button" onClick={() => setMobileMenuOpen(true)} aria-label="Open menu"><Menu size={23} /></button>
          <button className="mobile-brand" onClick={() => goTo("explore")}><span className="mobile-brand-icon"><Wrench size={19} /></span>Sevai<span>Go</span></button>
          <div className="topbar-breadcrumb"><span>{view === "explore" ? "Home" : "Your space"}</span><ChevronRight size={14} /><strong>{view === "explore" ? "Find a mechanic" : view === "saved" ? t(language, "navSaved") : view === "vehicles" ? t(language, "navVehicles") : view === "activity" ? t(language, "navActivity") : view === "admin" ? t(language, "navAdmin") : t(language, "navOwner")}</strong></div>
          <div className="topbar-actions">
            <button className="topbar-location" onClick={() => detectLocation()} title={t(language, "useLocation")}><span className="topbar-location-icon"><MapPin size={18} fill="currentColor" /></span><span className="topbar-location-text"><strong>{location.label}</strong><small>{geoLoading ? "Detecting location..." : t(language, location.source === "gps" ? "gpsActive" : "demoLocation")}</small></span><ChevronDown size={15} className="topbar-location-chevron" /></button>
            <button className="topbar-icon-button" onClick={openNotifications} aria-label="Notifications"><Bell size={20} />{unreadCount > 0 && <span className="notification-dot" />}</button>
            <button className="topbar-profile" onClick={() => user ? goTo("vehicles") : setAuthOpen(true)} aria-label={user ? "My account" : t(language, "signIn")}>{user ? user.name.slice(0, 1).toUpperCase() : <UserRound size={18} />}</button>
          </div>
          {notificationOpen && <div className="notification-popover"><div className="popover-header"><strong>{t(language, "alerts")}</strong><button onClick={() => setNotificationOpen(false)}><X size={16} /></button></div>{notices.length ? notices.slice(0, 5).map((notice) => <div className="popover-notice" key={notice.id}><span className="popover-notice-dot" /><div><strong>{notice.title}</strong><p>{notice.message}</p><small>{dateLabel(notice.createdAt, language)}</small></div></div>) : <p className="popover-empty">{t(language, "noAlerts")}</p>}<button className="popover-footer" onClick={() => goTo("activity")}>View all activity <ArrowRight size={15} /></button></div>}
        </header>

        <main className="main-content">
          {view === "explore" && <>
            <div className="page-intro"><div><div className="eyebrow"><span className="eyebrow-line" />{t(language, "pageEyebrow")}</div><h1>{t(language, "pageTitle")}</h1><p>{t(language, "pageSubtitle")}</p></div><div className="verified-pill"><ShieldCheck size={17} />{t(language, "verifiedWorkshops")}</div></div>

            <section className="emergency-banner" aria-label="Vehicle breakdown help">
              <div className="emergency-copy"><div className="emergency-eyebrow"><span className="emergency-pulse" />{t(language, "heroEyebrow")}</div><h2>{t(language, "heroTitleA")} <span>{t(language, "heroTitleB")}</span></h2><p>{t(language, "heroDescription")}</p><button className="emergency-button" onClick={() => detectLocation(true)} disabled={geoLoading}><span className="emergency-button-icon"><Zap size={18} fill="currentColor" /></span>{geoLoading ? "Finding your location..." : t(language, "heroButton")}<ArrowRight size={18} /></button></div>
              <div className="emergency-art" aria-hidden="true"><div className="art-orbit art-orbit-1" /><div className="art-orbit art-orbit-2" /><div className="art-dashed-route" /><div className="art-car"><CarFront size={32} strokeWidth={2.2} /></div><div className="art-wrench"><Wrench size={29} strokeWidth={2.25} /></div><div className="art-verified"><CheckCircle2 size={16} />{t(language, "heroMini")}</div></div>
            </section>

            <section className="results-section" id="results">
              <div className="section-heading"><div><div className="section-heading-title"><h2>{t(language, "mechanicsNear")}</h2><span className="section-count">{filteredShops.length}</span></div><p>{t(language, "withinRadius")}</p></div><div className="ready-indicator"><span />{readyCount} {t(language, "shopsReady")}</div></div>
              {offline && <div className="offline-notice">Offline mode · Showing your last saved mechanic list</div>}
              {emergencyMode && <div className="emergency-active-strip"><Zap size={17} fill="currentColor" /><span>Emergency search active — choose a nearby workshop to call or navigate.</span><button onClick={() => setEmergencyMode(false)} aria-label="Dismiss emergency status"><X size={15} /></button></div>}
              <div className="filters-panel"><div className="filters-primary"><label className="search-field"><Search size={18} /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder={t(language, "searchPlaceholder")} aria-label="Search workshops" />{search && <button onClick={() => setSearch("")} aria-label="Clear search"><X size={15} /></button>}</label><div className="filter-divider" /><div className="vehicle-filters">{vehicleChoices.map(({ value, key, Icon }) => <button key={value} className={`vehicle-filter ${vehicleFilter === value ? "active" : ""}`} onClick={() => setVehicleFilter(value)}><Icon size={16} />{t(language, key)}</button>)}</div></div><div className="filters-secondary"><div className="quick-filters"><button className={`quick-filter ${openOnly ? "active" : ""}`} onClick={() => setOpenOnly((previous) => !previous)}><span className="quick-filter-dot" />{t(language, "openNow")}</button><button className={`quick-filter ${availableOnly ? "active" : ""}`} onClick={() => setAvailableOnly((previous) => !previous)}><Check size={15} />{t(language, "available")}</button></div><label className="sort-select"><SlidersHorizontal size={16} /><span>Sort:</span><select value={sort} onChange={(event) => setSort(event.target.value)} aria-label="Sort mechanics"><option value="distance">{t(language, "nearest")}</option><option value="rating">{t(language, "topRated")}</option><option value="open">{t(language, "openFirst")}</option><option value="availability">{t(language, "availableFirst")}</option></select><ChevronDown size={14} /></label></div></div>

              <div className="discovery-grid">
                <div className="listing-panel"><div className="listing-header"><div><span className="listing-header-icon"><Wrench size={17} /></span><h3>{t(language, "nearbyWorkshops")}</h3></div><span className="listing-found">{filteredShops.length} {t(language, "found")}</span></div><div className="listing-scroll">{loadingShops && <div className="list-loading"><span className="loading-spinner" />Finding mechanics near you...</div>}{filteredShops.length ? filteredShops.map((shop) => <ShopCard key={shop.id} shop={shop} language={language} isSaved={favoriteIds.includes(shop.id)} onOpen={openShop} onFavorite={toggleFavorite} onCall={(item) => recordAction(item, "call")} />) : !loadingShops && <div className="no-results"><span><Search size={27} /></span><h3>{t(language, "noShops")}</h3><p>{t(language, "noShopsDesc")}</p><button onClick={clearFilters}>{t(language, "clearFilters")} <ArrowRight size={15} /></button></div>}</div></div>
                <div className="map-panel"><MechanicMap shops={filteredShops} location={location} selectedId={selectedId} onSelect={(id) => { const shop = shops.find((item) => item.id === id); if (shop) openShop(shop); }} /><div className="map-live-chip"><span className="map-live-dot" />{t(language, "liveMap")}<span className="map-chip-divider" />{filteredShops.length} shops nearby</div><button className="map-locate-button" onClick={() => detectLocation()} title={t(language, "useLocation")} aria-label={t(language, "useLocation")}><LocateFixed size={20} /></button><div className="map-location-chip"><span><MapPin size={17} /></span><div><small>{t(language, "yourLocation")}</small><strong>{location.label}</strong></div></div></div>
              </div>
              <div className="trust-strip"><div><span><ShieldCheck size={21} /></span><p><strong>Verified workshops</strong><small>Every listed shop is reviewed</small></p></div><div><span><Navigation size={21} /></span><p><strong>Nearby & convenient</strong><small>Help within a 5 km radius</small></p></div><div><span><Phone size={21} /></span><p><strong>Direct connection</strong><small>Call the mechanic in one tap</small></p></div></div>
            </section>
          </>}

          {view === "saved" && <div className="subpage"><div className="subpage-header"><div className="eyebrow"><span className="eyebrow-line" />YOUR SPACE / SAVED SHOPS</div><h1>{t(language, "savedTitle")}</h1><p>{t(language, "savedSubtitle")}</p></div>{!user ? gate() : savedShops.length ? <div className="saved-grid">{savedShops.map((shop) => <ShopCard key={shop.id} shop={shop} language={language} isSaved onOpen={openShop} onFavorite={toggleFavorite} onCall={(item) => recordAction(item, "call")} />)}</div> : <div className="empty-state"><span className="empty-icon"><Heart size={31} /></span><h2>{t(language, "savedEmpty")}</h2><p>{t(language, "savedEmptyDesc")}</p><button className="primary-button" onClick={() => goTo("explore")}>{t(language, "browseMechanics")} <ArrowRight size={17} /></button></div>}</div>}

          {view === "vehicles" && <div className="subpage"><div className="subpage-header"><div className="eyebrow"><span className="eyebrow-line" />YOUR SPACE / GARAGE</div><h1>{t(language, "vehiclesTitle")}</h1><p>{t(language, "vehiclesSubtitle")}</p></div>{!user ? gate() : <div className="vehicle-layout"><div className="content-card"><div className="card-heading"><div><span className="heading-icon"><CarFront size={19} /></span><h2>{t(language, "yourVehicles")}</h2></div><span className="count-badge">{vehicles.length}</span></div>{vehicles.length ? <div className="vehicle-list">{vehicles.map((vehicle) => <div className="vehicle-item" key={vehicle.id}><div className="vehicle-illustration">{vehicle.type === "2w" ? <Bike size={29} /> : vehicle.type === "truck" ? <Truck size={29} /> : <CarFront size={29} />}</div><div className="vehicle-item-copy"><strong>{vehicle.make} {vehicle.model}</strong><span>{vehicle.year} · {vehicleChoices.find((choice) => choice.value === vehicle.type) ? t(language, vehicleChoices.find((choice) => choice.value === vehicle.type)!.key) : vehicle.type}{vehicle.registration ? ` · ${vehicle.registration.toUpperCase()}` : ""}</span>{new Date().getFullYear() - vehicle.year >= 5 && <small className="service-note"><Sparkles size={13} />{t(language, "serviceReminder")}</small>}</div><button className="delete-icon" onClick={() => removeVehicle(vehicle.id)} title={t(language, "remove")} aria-label={`Remove ${vehicle.make} ${vehicle.model}`}><Trash2 size={17} /></button></div>)}</div> : <div className="inline-empty"><CarFront size={34} /><strong>{t(language, "noVehicles")}</strong><p>{t(language, "noVehiclesDesc")}</p></div>}</div><div className="content-card"><div className="card-heading"><div><span className="heading-icon accent"><Plus size={19} /></span><h2>{t(language, "addVehicle")}</h2></div></div><form className="app-form" onSubmit={submitVehicle}><div className="form-grid two"><label>{t(language, "make")}<input required value={vehicleForm.make} onChange={(event) => setVehicleForm({ ...vehicleForm, make: event.target.value })} placeholder="e.g. Hyundai" maxLength={60} /></label><label>{t(language, "model")}<input required value={vehicleForm.model} onChange={(event) => setVehicleForm({ ...vehicleForm, model: event.target.value })} placeholder="e.g. i20" maxLength={60} /></label></div><div className="form-grid two"><label>{t(language, "year")}<input required type="number" min="1950" max={new Date().getFullYear() + 1} value={vehicleForm.year} onChange={(event) => setVehicleForm({ ...vehicleForm, year: event.target.value })} /></label><label>{t(language, "vehicleType")}<select value={vehicleForm.type} onChange={(event) => setVehicleForm({ ...vehicleForm, type: event.target.value })}>{vehicleChoices.filter((choice) => choice.value !== "all").map((choice) => <option key={choice.value} value={choice.value}>{t(language, choice.key)}</option>)}</select></label></div><label>{t(language, "registration")}<input value={vehicleForm.registration} onChange={(event) => setVehicleForm({ ...vehicleForm, registration: event.target.value })} placeholder="TN 01 AB 1234" maxLength={25} /></label><button className="primary-button form-submit" disabled={vehicleSubmitting}>{vehicleSubmitting ? "Saving..." : t(language, "saveVehicle")} <ArrowRight size={17} /></button></form></div></div>}</div>}

          {view === "activity" && <div className="subpage"><div className="subpage-header"><div className="eyebrow"><span className="eyebrow-line" />YOUR SPACE / ACTIVITY</div><h1>{t(language, "activityTitle")}</h1><p>{t(language, "activitySubtitle")}</p></div>{!user ? gate() : <div className="activity-layout"><div className="content-card"><div className="card-heading"><div><span className="heading-icon"><Clock3 size={19} /></span><h2>{t(language, "pastBreakdowns")}</h2></div><span className="count-badge">{breakdowns.length}</span></div>{breakdowns.length ? <div className="activity-list">{breakdowns.map((item) => <button className="activity-item" key={item.id} onClick={() => { const shop = shops.find((row) => row.id === item.mechanicId) || favoriteShops.find((row) => row.id === item.mechanicId); if (shop) openShop(shop); else say("This workshop is outside your current search area."); }}><span className="activity-action-icon">{item.action === "navigated" ? <Navigation size={18} /> : <Phone size={18} />}</span><span><strong>{item.shopName}</strong><small>{item.action === "navigated" ? "Navigated to workshop" : "Called mechanic"} · {dateLabel(item.createdAt, language)}</small></span><ChevronRight size={18} /></button>)}</div> : <div className="inline-empty"><Clock3 size={34} /><strong>{t(language, "noActivity")}</strong><p>{t(language, "noActivityDesc")}</p></div>}</div><div className="content-card"><div className="card-heading"><div><span className="heading-icon blue"><Bell size={19} /></span><h2>{t(language, "alerts")}</h2></div>{notices.length > 0 && <span className="count-badge">{notices.length}</span>}</div>{notices.length ? <div className="notice-list">{notices.map((notice) => <div className="notice-item" key={notice.id}><span className="notice-icon"><CheckCircle2 size={18} /></span><div><strong>{notice.title}</strong><p>{notice.message}</p><small>{dateLabel(notice.createdAt, language)}</small></div></div>)}</div> : <div className="inline-empty"><Bell size={34} /><p>{t(language, "noAlerts")}</p></div>}</div></div>}</div>}

          {(view === "partner" || view === "owner") && <div className="subpage partner-page"><div className="subpage-header"><div className="eyebrow"><span className="eyebrow-line" />SEVAIGO / FOR PARTNERS</div><h1>{ownerShop ? t(language, "ownerTitle") : t(language, "partnerTitle")}</h1><p>{ownerShop ? t(language, "ownerSubtitle") : t(language, "partnerSubtitle")}</p></div>{!user ? gate() : ownerShop ? <div className="owner-layout"><div className="owner-overview content-card"><div className="owner-cover">{/* eslint-disable-next-line @next/next/no-img-element */}<img src={ownerShop.photos[0] || "/images/workshop-1.jpg"} alt={ownerShop.shopName} /></div><div className="owner-overview-body"><span className={`owner-status ${ownerShop.approvalStatus}`}>{ownerShop.approvalStatus === "approved" ? <CheckCircle2 size={15} /> : <Clock3 size={15} />}{ownerShop.approvalStatus === "approved" ? t(language, "approved") : ownerShop.approvalStatus === "rejected" ? t(language, "rejected") : t(language, "pendingApproval")}</span><h2>{ownerShop.shopName}</h2><p><MapPin size={15} />{ownerShop.address}</p><p><Phone size={15} />{ownerShop.phone}</p>{ownerShop.approvalStatus === "pending" && <div className="pending-note"><ShieldCheck size={19} /><span>Your shop is under review. It will appear on the map once approved by the SevaiGo team.</span></div>}</div></div><div className="content-card"><div className="card-heading"><div><span className="heading-icon"><Settings2 size={19} /></span><h2>Manage workshop</h2></div></div><form className="app-form" onSubmit={saveOwner}><div className="form-section-label">{t(language, "updateAvailability")}</div><div className="availability-choice"><button type="button" className={ownerDraft.availabilityStatus === "free" ? "selected free" : ""} onClick={() => setOwnerDraft({ ...ownerDraft, availabilityStatus: "free" })}><span className="choice-dot free" />{t(language, "freeNow")}</button><button type="button" className={ownerDraft.availabilityStatus === "busy" ? "selected busy" : ""} onClick={() => setOwnerDraft({ ...ownerDraft, availabilityStatus: "busy" })}><span className="choice-dot busy" />{t(language, "busyNow")}</button></div><div className="form-section-label">{t(language, "hours")}</div><div className="form-grid two"><label>{t(language, "opensAt")}<input type="time" required value={ownerDraft.openTime} onChange={(event) => setOwnerDraft({ ...ownerDraft, openTime: event.target.value })} /></label><label>{t(language, "closesAt")}<input type="time" required value={ownerDraft.closeTime} onChange={(event) => setOwnerDraft({ ...ownerDraft, closeTime: event.target.value })} /></label></div><div className="form-section-label">{t(language, "updatePrices")}</div><div className="form-grid two"><label>{t(language, "priceMin")}<input type="number" min="0" required value={ownerDraft.priceMin} onChange={(event) => setOwnerDraft({ ...ownerDraft, priceMin: event.target.value })} /></label><label>{t(language, "priceMax")}<input type="number" min="0" required value={ownerDraft.priceMax} onChange={(event) => setOwnerDraft({ ...ownerDraft, priceMax: event.target.value })} /></label></div><button className="primary-button form-submit" disabled={ownerSaving}>{ownerSaving ? "Saving..." : t(language, "saveChanges")} <ArrowRight size={17} /></button></form></div></div> : <><div className="partner-banner"><div><span><Sparkles size={15} /> WORK WITH US</span><h2>{t(language, "partnerHeroTitle")}</h2><p>{t(language, "partnerHeroDesc")}</p></div><Store size={90} strokeWidth={1.2} /></div><form className="partner-form content-card app-form" onSubmit={submitPartner}><div className="card-heading"><div><span className="heading-icon"><Store size={19} /></span><h2>Workshop details</h2></div><span className="step-badge">01 / 03</span></div><div className="form-grid two"><label>{t(language, "shopName")}<input required minLength={3} value={partnerForm.shopName} onChange={(event) => setPartnerForm({ ...partnerForm, shopName: event.target.value })} placeholder="e.g. My Auto Garage" /></label><label>{t(language, "ownerName")}<input required value={partnerForm.ownerName} onChange={(event) => setPartnerForm({ ...partnerForm, ownerName: event.target.value })} placeholder="Your full name" /></label></div><div className="form-grid two"><label>{t(language, "contactNumber")}<input required type="tel" value={partnerForm.phone} onChange={(event) => setPartnerForm({ ...partnerForm, phone: event.target.value })} placeholder="+91 98765 43210" /></label><label>{t(language, "address")}<input required value={partnerForm.address} onChange={(event) => setPartnerForm({ ...partnerForm, address: event.target.value })} placeholder="Street, area, city" /></label></div><div className="form-section-label">Workshop location <button type="button" className="inline-link" onClick={() => { if (!navigator.geolocation) { say("Location isn't available."); return; } navigator.geolocation.getCurrentPosition((position) => { setPartnerForm((previous) => ({ ...previous, latitude: String(position.coords.latitude), longitude: String(position.coords.longitude) })); say("Workshop coordinates added."); }, () => say("Allow location access to fill coordinates.")); }}><LocateFixed size={14} /> Use current location</button></div><div className="form-grid two"><label>{t(language, "latitude")}<input required type="number" step="any" value={partnerForm.latitude} onChange={(event) => setPartnerForm({ ...partnerForm, latitude: event.target.value })} /></label><label>{t(language, "longitude")}<input required type="number" step="any" value={partnerForm.longitude} onChange={(event) => setPartnerForm({ ...partnerForm, longitude: event.target.value })} /></label></div><div className="form-section-label">{t(language, "vehicleType")}</div><div className="checkbox-grid">{vehicleChoices.filter((choice) => choice.value !== "all").map(({ value, key, Icon }) => <button key={value} type="button" className={`select-chip ${partnerForm.vehicleTypes.includes(value) ? "active" : ""}`} onClick={() => togglePartnerArray("vehicleTypes", value)}><Icon size={16} />{t(language, key)}{partnerForm.vehicleTypes.includes(value) && <Check size={15} />}</button>)}</div><div className="form-section-label">{t(language, "specializations")}</div><div className="checkbox-grid">{specialtyChoices.map((specialty) => <button key={specialty} type="button" className={`select-chip ${partnerForm.specializations.includes(specialty) ? "active" : ""}`} onClick={() => togglePartnerArray("specializations", specialty)}>{specialty}{partnerForm.specializations.includes(specialty) && <Check size={15} />}</button>)}</div><div className="form-grid three"><label>{t(language, "opensAt")}<input required type="time" value={partnerForm.openTime} onChange={(event) => setPartnerForm({ ...partnerForm, openTime: event.target.value })} /></label><label>{t(language, "closesAt")}<input required type="time" value={partnerForm.closeTime} onChange={(event) => setPartnerForm({ ...partnerForm, closeTime: event.target.value })} /></label><label>Years of experience<input required type="number" min="0" max="70" value={partnerForm.yearsExperience} onChange={(event) => setPartnerForm({ ...partnerForm, yearsExperience: event.target.value })} /></label></div><div className="form-grid two"><label>{t(language, "priceMin")}<input required type="number" min="0" value={partnerForm.priceMin} onChange={(event) => setPartnerForm({ ...partnerForm, priceMin: event.target.value })} /></label><label>{t(language, "priceMax")}<input required type="number" min="0" value={partnerForm.priceMax} onChange={(event) => setPartnerForm({ ...partnerForm, priceMax: event.target.value })} /></label></div><div className="form-grid two"><label>{t(language, "ownerPhotoUrl")}<input type="url" value={partnerForm.ownerPhoto} onChange={(event) => setPartnerForm({ ...partnerForm, ownerPhoto: event.target.value })} placeholder="https://..." /></label><label>{t(language, "workshopPhotoUrl")}<input type="url" value={partnerForm.photo} onChange={(event) => setPartnerForm({ ...partnerForm, photo: event.target.value })} placeholder="https://..." /></label></div><div className="form-bottom"><p><ShieldCheck size={16} /> Listings go live after admin verification.</p><button className="primary-button" disabled={partnerSubmitting}>{partnerSubmitting ? "Submitting..." : t(language, "submitShop")} <ArrowRight size={17} /></button></div></form></>}</div>}

          {view === "admin" && <div className="subpage"><div className="subpage-header"><div className="eyebrow"><span className="eyebrow-line" />SEVAIGO / ADMIN</div><h1>{t(language, "adminTitle")}</h1><p>{t(language, "adminSubtitle")}</p></div>{user?.role !== "admin" ? gate() : <div className="admin-list">{pendingShops.length ? pendingShops.map((shop) => <div className="admin-card content-card" key={shop.id}><div className="admin-card-top">{/* eslint-disable-next-line @next/next/no-img-element */}<img src={shop.photos[0] || "/images/workshop-1.jpg"} alt={shop.shopName} /><div><span className="owner-status pending">{t(language, "pendingApproval")}</span><h2>{shop.shopName}</h2><p>{shop.ownerName} · {shop.phone}</p><p><MapPin size={14} />{shop.address}</p></div></div><div className="admin-card-bottom"><span>{shop.vehicleTypes.join(" · ")} · {shop.specializations.join(", ")}</span><div><button className="reject-button" onClick={() => handleApproval(shop.id, "rejected")}>{t(language, "reject")}</button><button className="primary-button" onClick={() => handleApproval(shop.id, "approved")}><Check size={16} />{t(language, "approve")}</button></div></div></div>) : <div className="empty-state"><span className="empty-icon"><CheckCircle2 size={31} /></span><h2>All caught up</h2><p>There are no workshop applications waiting for review.</p></div>}</div>}</div>}
        </main>
        <footer className="workspace-footer"><span>© {new Date().getFullYear()} SevaiGo · Made for the road ahead.</span><span><ShieldCheck size={14} /> Helping you move with confidence</span></footer>
        <nav className="mobile-bottom-nav" aria-label="Mobile navigation">{primaryNav.map(({ view: itemView, label, Icon }) => <button key={itemView} className={view === itemView ? "active" : ""} onClick={() => goTo(itemView)}><Icon size={21} /><span>{label}</span></button>)}<button onClick={() => setMobileMenuOpen(true)}><Menu size={21} /><span>More</span></button></nav>
      </div>

      {selectedShop && <ShopDetail shop={selectedShop} language={language} isSaved={favoriteIds.includes(selectedShop.id)} user={user} reviews={reviews} reviewSubmitting={reviewSubmitting} onClose={() => setSelectedId(null)} onFavorite={toggleFavorite} onCall={(shop) => recordAction(shop, "call")} onNavigate={(shop) => recordAction(shop, "navigate")} onShare={shareShop} onSubmitReview={submitReview} onAuth={() => { setSelectedId(null); setAuthOpen(true); }} />}
      {authOpen && <div className="auth-overlay" onMouseDown={(event) => { if (event.target === event.currentTarget) setAuthOpen(false); }}><div className="auth-modal" role="dialog" aria-modal="true" aria-label={t(language, "authTitle")}><button className="auth-close" onClick={() => setAuthOpen(false)} aria-label="Close"><X size={20} /></button><div className="auth-logo"><Wrench size={24} /></div><h2>{t(language, "authTitle")}</h2><p>{t(language, "authSubtitle")}</p><div className="auth-tabs"><button type="button" className={authMode === "login" ? "active" : ""} onClick={() => { setAuthMode("login"); setAuthError(""); }}>{t(language, "signIn")}</button><button type="button" className={authMode === "register" ? "active" : ""} onClick={() => { setAuthMode("register"); setAuthError(""); }}>{t(language, "createAccount")}</button></div><form className="app-form auth-form" onSubmit={submitAuth}>{authMode === "register" && <><label>{t(language, "fullName")}<input required minLength={2} value={authName} onChange={(event) => setAuthName(event.target.value)} placeholder="Your name" autoComplete="name" /></label><label>{t(language, "contactNumber")} <small>(optional)</small><input type="tel" value={authPhone} onChange={(event) => setAuthPhone(event.target.value)} placeholder="+91 98765 43210" autoComplete="tel" /></label></>}<label>{t(language, "email")}<input required type="email" value={authEmail} onChange={(event) => setAuthEmail(event.target.value)} placeholder="you@example.com" autoComplete="email" /></label><label>{t(language, "password")}<input required type="password" minLength={6} value={authPassword} onChange={(event) => setAuthPassword(event.target.value)} placeholder="At least 6 characters" autoComplete={authMode === "register" ? "new-password" : "current-password"} /></label>{authError && <p className="form-error">{authError}</p>}<button type="submit" className="primary-button auth-submit" disabled={authSubmitting}>{authSubmitting ? "Please wait..." : authMode === "register" ? t(language, "createAccount") : t(language, "signIn")} <ArrowRight size={17} /></button></form><div className="auth-footnote"><ShieldCheck size={15} /> You can always find and call mechanics without signing in.</div></div></div>}
      {toast && <div className="toast-message" role="status"><CheckCircle2 size={18} />{toast}<button onClick={() => setToast("")} aria-label="Dismiss"><X size={14} /></button></div>}
    </div>
  );
}
