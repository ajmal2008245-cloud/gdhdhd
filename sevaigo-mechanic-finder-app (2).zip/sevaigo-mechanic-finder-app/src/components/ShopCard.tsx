"use client";

import { ArrowUpRight, Heart, MapPin, Phone, Star } from "lucide-react";
import type { MechanicView } from "@/lib/mechanic-shared";
import { t, type Language } from "@/lib/copy";

type Props = {
  shop: MechanicView;
  language: Language;
  isSaved: boolean;
  onOpen: (shop: MechanicView) => void;
  onFavorite: (shop: MechanicView) => void;
  onCall: (shop: MechanicView) => void;
};

export function formatDistance(km: number) {
  return km < 1 ? `${Math.round(km * 1000)} m` : `${km.toFixed(1)} km`;
}

export default function ShopCard({ shop, language, isSaved, onOpen, onFavorite, onCall }: Props) {
  const status = !shop.isOpen ? "closed" : shop.availabilityStatus === "busy" ? "busy" : "free";
  const statusText = status === "closed" ? t(language, "currentlyClosed") : status === "busy" ? t(language, "busyNow") : t(language, "freeNow");
  return (
    <article className="shop-card" onClick={() => onOpen(shop)} onKeyDown={(event) => { if (event.key === "Enter") onOpen(shop); }} tabIndex={0} role="button" aria-label={`${shop.shopName}, ${formatDistance(shop.distanceKm)} away. View details`}>
      <div className="shop-card-main">
        <div className="shop-card-image-wrap">
          {/* Workshop URLs can also be provided by approved owners. */}
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img className="shop-card-image" src={shop.photos[0] || "/images/workshop-1.jpg"} alt={`${shop.shopName} workshop`} />
        </div>
        <div className="shop-card-info">
          <div className="shop-card-title-row">
            <h3>{shop.shopName}</h3>
            <button type="button" className={`favorite-button ${isSaved ? "is-saved" : ""}`} onClick={(event) => { event.stopPropagation(); onFavorite(shop); }} aria-label={isSaved ? "Remove from saved shops" : "Save workshop"}>
              <Heart size={17} strokeWidth={2} fill={isSaved ? "currentColor" : "none"} />
            </button>
          </div>
          <p className="shop-card-address"><MapPin size={13} strokeWidth={2} /> <span>{shop.address}</span></p>
          <div className="shop-card-metrics">
            <span className="rating-value"><Star size={13} fill="currentColor" strokeWidth={1.5} /> {shop.rating.toFixed(1)}</span>
            <span className="review-count">({shop.reviewCount})</span>
            <span className="metric-separator">•</span>
            <span className="distance-value">{formatDistance(shop.distanceKm)} {t(language, "away")}</span>
          </div>
          <div className="shop-card-tags">
            {shop.specializations.slice(0, 2).map((specialty) => <span key={specialty}>{specialty}</span>)}
          </div>
        </div>
      </div>
      <div className="shop-card-footer">
        <span className={`availability-label ${status}`}><span className="availability-dot" />{statusText}</span>
        <div className="shop-card-actions">
          <a className="card-call" href={`tel:${shop.phone}`} aria-label={`Call ${shop.shopName}`} onClick={(event) => { event.stopPropagation(); onCall(shop); }}><Phone size={15} strokeWidth={2.2} /></a>
          <button type="button" className="card-details" onClick={(event) => { event.stopPropagation(); onOpen(shop); }}>{t(language, "viewDetails")} <ArrowUpRight size={15} /></button>
        </div>
      </div>
    </article>
  );
}
