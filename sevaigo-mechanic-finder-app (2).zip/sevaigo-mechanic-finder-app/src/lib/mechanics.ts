import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { mechanics } from "@/db/schema";
import { ensureSeed } from "@/lib/seed";
import { type MechanicView } from "@/lib/mechanic-shared";
export { DEMO_LOCATION } from "@/lib/mechanic-shared";
export type { MechanicView } from "@/lib/mechanic-shared";

type MechanicRow = typeof mechanics.$inferSelect;

export type MechanicQuery = {
  latitude: number;
  longitude: number;
  radiusKm?: number;
  vehicleType?: string;
  search?: string;
  sort?: string;
  openOnly?: boolean;
  availableOnly?: boolean;
};

export function distanceKm(lat1: number, lon1: number, lat2: number, lon2: number) {
  const rad = Math.PI / 180;
  const dLat = (lat2 - lat1) * rad;
  const dLon = (lon2 - lon1) * rad;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(lat1 * rad) * Math.cos(lat2 * rad) * Math.sin(dLon / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function isShopOpen(openTime: string, closeTime: string) {
  const current = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Kolkata", hour: "2-digit", minute: "2-digit", hour12: false,
  }).format(new Date());
  if (openTime <= closeTime) return current >= openTime && current <= closeTime;
  return current >= openTime || current <= closeTime;
}

export function toMechanicView(row: MechanicRow, latitude: number, longitude: number): MechanicView {
  const distance = distanceKm(latitude, longitude, row.latitude, row.longitude);
  return {
    id: row.id,
    slug: row.slug,
    shopName: row.shopName,
    ownerName: row.ownerName,
    ownerPhoto: row.ownerPhoto,
    phone: row.phone,
    address: row.address,
    latitude: row.latitude,
    longitude: row.longitude,
    vehicleTypes: row.vehicleTypes,
    specializations: row.specializations,
    openTime: row.openTime,
    closeTime: row.closeTime,
    rating: row.rating,
    reviewCount: row.reviewCount,
    photos: row.photos,
    isVerified: row.isVerified,
    availabilityStatus: row.availabilityStatus,
    priceMin: row.priceMin,
    priceMax: row.priceMax,
    yearsExperience: row.yearsExperience,
    distanceKm: Math.round(distance * 10) / 10,
    etaMinutes: Math.max(2, Math.round(distance * 3.5 + 2)),
    isOpen: isShopOpen(row.openTime, row.closeTime),
  };
}

export async function getNearbyMechanics(query: MechanicQuery): Promise<MechanicView[]> {
  await ensureSeed();
  const rows = await db.select().from(mechanics).where(and(
    eq(mechanics.isVerified, true), eq(mechanics.approvalStatus, "approved"),
  ));
  const radius = Math.min(Math.max(query.radiusKm ?? 5, 0.5), 50);
  const term = query.search?.trim().toLowerCase();
  const shops = rows
    .map((row) => toMechanicView(row, query.latitude, query.longitude))
    .filter((shop) => shop.distanceKm <= radius)
    .filter((shop) => !query.vehicleType || query.vehicleType === "all" || shop.vehicleTypes.includes(query.vehicleType))
    .filter((shop) => !term || `${shop.shopName} ${shop.address} ${shop.specializations.join(" ")}`.toLowerCase().includes(term))
    .filter((shop) => !query.openOnly || shop.isOpen)
    .filter((shop) => !query.availableOnly || (shop.isOpen && shop.availabilityStatus === "free"));

  shops.sort((a, b) => {
    if (query.sort === "rating") return b.rating - a.rating || a.distanceKm - b.distanceKm;
    if (query.sort === "open") return Number(b.isOpen) - Number(a.isOpen) || a.distanceKm - b.distanceKm;
    if (query.sort === "availability") return Number(b.isOpen && b.availabilityStatus === "free") - Number(a.isOpen && a.availabilityStatus === "free") || a.distanceKm - b.distanceKm;
    return a.distanceKm - b.distanceKm;
  });
  return shops;
}
